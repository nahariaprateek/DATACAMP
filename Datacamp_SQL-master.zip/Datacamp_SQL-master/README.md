 # SQL Fundamentals
 
 <p align="center"> 
<img src="https://cdn.datacamp.com/main-app/assets/brand/logos/DataCamp_Horizontal_RGB-d196011f63ebda76dc5c9772425cf9541b8639af842d5e5476ef10f2460ed1e4.png" width="500">
</p>

 
It contains the SQL solution of the following tracks with DataSet.
- Joining Data In SQL
- Intermediate SQL
- PostgreSQL Summary Stats and Window Functions 
- Functions for Manipulating Data in PostgreSQL